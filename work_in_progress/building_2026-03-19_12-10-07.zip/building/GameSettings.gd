extends Node

var seed: int = 0
var selected_character: String = "Ranger"
